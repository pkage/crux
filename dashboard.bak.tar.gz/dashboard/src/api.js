class CruxAPIClient {
	components = []
	daemon_addr = null
	
}
