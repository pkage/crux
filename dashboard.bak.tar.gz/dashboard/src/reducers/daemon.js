const initialState = {
	connections: []
}

const daemonReducer = (state = initialState, action) => {
	switch (action) {
		case 'CONNECT_DAEMON':
			return {...state, connections: [action.uri]}
		default:
			break
	}

	return state
}

export default daemonReducer
