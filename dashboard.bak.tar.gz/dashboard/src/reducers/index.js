import { combineReducers } from 'redux'

import daemonReducer from './daemon'

const reducers = combineReducers({
	daemon: daemonReducer
})

export default reducers
