export const connect_daemon = (addr) => ({
	type: 'CONNECT_DAEMON',
	addr
})
