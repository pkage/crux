import React from 'react'
import ReactDOM from 'react-dom'
import App from './components/app'
import './styles/index.css'

import { Provider } from 'react-redux'
import { createStore } from 'redux'
import reducers from './reducers'

const APIURL = 'http://127.0.0.1:8080'
const store = createStore(reducers)
ReactDOM.render(
	<Provider store={store}>
		<App apiurl={APIURL}/>
	</Provider>,
	document.getElementById('root')
)
