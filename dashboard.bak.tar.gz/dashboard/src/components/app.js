import React, { Component } from 'react'
import {Route, BrowserRouter as Router } from 'react-router-dom'
//import 'bulma/css/bulma.css'

import Navigation from './nav'
import DaemonContainer from '../containers/daemon'
import ComponentsView from './components'
import PipelineView from './pipeline'
import ExecutionView from './execution'

class App extends Component {
	render() {
		return (
			<Router>
				<div>
					<Route path='/' component={Navigation}/>
					<Route path='/daemons' component={DaemonContainer}/>
					<Route path='/components' component={ComponentsView}/>
					<Route path='/pipelines' component={PipelineView}/>
					<Route path='/execution' component={ExecutionView}/>
					
				</div>
			</Router>
		);
	}
}

export default App;
