import React from 'react'

class ComponentsView extends React.Component {
	render() {
		return <p>component view</p>
	}
}

export default ComponentsView
