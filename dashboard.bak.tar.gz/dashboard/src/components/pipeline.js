import React from 'react'

class PipelineView extends React.Component {
	render() {
		return <p>pipeline view</p>
	}
}

export default PipelineView

