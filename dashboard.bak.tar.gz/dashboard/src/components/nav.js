import React from 'react'
import { Link } from 'react-router-dom'

class Navigation extends React.Component {
	render() {
		const is_selected = (name) => {
			if ('/' + name.toLowerCase() === window.location.pathname) {
				return (
					<strong>{name}</strong>
				)
			}
			return <Link to={name.toLowerCase()}>{name}</Link>
		}
		return (
			<div className="container is-fluid top-bottom-margin">
				<nav className="level is-mobile">
					<div className="level-left">
						<div className="level-item">
							<strong className="is-size-4">Crux</strong>
						</div>
					</div>
					<div className="level-right">
						<div className="level-item">
							{is_selected('Daemons')}
						</div>
						<div className="level-item">
							{is_selected('Components')}
						</div>
						<div className="level-item">
							{is_selected('Pipelines')}
						</div>
						<div className="level-item">
							{is_selected('Execution')}
						</div>
					</div>
				</nav>
			</div>
		)
	}
}

export default Navigation
