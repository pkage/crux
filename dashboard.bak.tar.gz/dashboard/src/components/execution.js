import React from 'react'

class ExecutionView extends React.Component {
	render() {
		return <p>execution view</p>
	}
}

export default ExecutionView
