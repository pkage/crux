import React from 'react'

class DaemonView extends React.Component {
	render () {
		const showDaemon = (addr) => (
			<article key={addr} className="hero-body">

				<div className="container is-mobile">
					<h1 className="title">{addr}</h1>
					<h2 className="subtitle">connected</h2>
				</div>

			</article>
		)
		console.log(this.props)
		return (
			<div>
				<section className="hero is-success is-medium is-bold is-mobile">
					{showDaemon('tcp://127.0.0.1:30020')}
				</section>
				<section className="section">
					<p>add daemon...</p>
				</section>
			</div>
		)
	}
}

export default DaemonView
