import { connect } from 'react-redux'
import { connect_daemon } from '../actions/daemon'
import Daemon from '../components/daemon'

const mapStateToProps = (state, ownProps) => {
	return {connections: state.daemon.connections}
}

const mapDispatchToProps = (dispatch, ownProps) => ({
	connectDaemon: (addr) => dispatch(connect_daemon(addr))
})

const DaemonContainer = connect(
	mapStateToProps,
	mapDispatchToProps
)(Daemon)

export default DaemonContainer
